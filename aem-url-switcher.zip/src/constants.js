// constants.js

export const COLORS = [
    { name: 'Grey', value: '#DADCE0' },
    { name: 'Blue', value: '#8AB4F8' },
    { name: 'Red', value: '#F28B82' },
    { name: 'Yellow', value: '#FDD663' },
    { name: 'Green', value: '#81C995' },
    { name: 'Pink', value: '#FF8BCB' },
    { name: 'Purple', value: '#C58AF9' },
    { name: 'Cyan', value: '#78D9EC' },
    { name: 'Orange', value: '#FCAD70' },
];